import React from "react";
import { CovidApp } from "./Components/CovidApp/index";
// import { ChartIndex } from "./Components/Charts/index";
// import { CartIndex } from "./Components/LoginCard/index";
export const App = () => {
  return (
    <div>
      <CovidApp />
    </div>
  );
};
