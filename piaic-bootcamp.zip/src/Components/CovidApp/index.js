import React from "react";
import Navbar from "../Navbar";
import BottomNavigation from "./BottomNav";
import Dividers from "./Divders";

export const CovidApp = () => {
  return (
    <div>
      <Navbar />
      <Dividers />
      <BottomNavigation />
    </div>
  );
};
