import { Charts } from '../Charts/Chart'
import React from 'react'

export const ChartIndex = () => {
  return (
    <div><Charts /></div>
  )
}
