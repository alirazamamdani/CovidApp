import React from 'react'
import CartNavbar from '../Navbar'
import CartBox from './LoginCard'

export const CartIndex = () => {
  return (
    <div>
        <CartNavbar />
        <CartBox />
    </div>
  )
}
